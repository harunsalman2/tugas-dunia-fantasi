// commanded variable //
var name = 'Ihsan'
var height = 166
age var = 18
money var = 30000

//existence of a desired command variable //
if (money <= 50000&&height <= 166){
}
if (height==='166') { //false
if (age < 20) {

//check to determine commanded result //
    console.log(name + "Sorry [visitor name], you cannot enter this area!");
} else {
    console.log (name + "Your height is less than the cm height difference and you lack as much money as the difference in money to ride your favorite ride! But don't worry, you can ride the Spin Horse!");
}
} else if (money <= 50000&&height <= 166) {
if(age < 20) {
    console.log(name +'Your height is less than cm to ride your favorite ride! But don't worry, you can ride Trilili!');
} else {
    console.log (name + 'Yeah you can ride your favorite ride! That's Kocar-Kacir');
}
}else {
    console.log('Please specify age and money first');
}